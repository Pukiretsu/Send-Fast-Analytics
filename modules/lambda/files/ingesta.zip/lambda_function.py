import os
import json
import datetime
import boto3
from decimal import Decimal # 👈 Importación necesaria
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('DYNAMODB_TABLE')
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        
        # Convertimos los números a Decimal para satisfacer a DynamoDB
        # Usamos str() primero para evitar errores de precisión de punto flotante
        monto = Decimal(str(body.get('monto', 0)))
        tiempo = Decimal(str(body.get('tiempo_entrega', 15)))
        
        item = {
            'orderId': body.get('orderId', f"ORD-{int(datetime.datetime.utcnow().timestamp())}"),
            'timestamp': datetime.datetime.utcnow().isoformat(),
            'ciudad_zona': body.get('ciudad_zona', 'Bogota-Centro'),
            'estado_pedido': body.get('estado_pedido', 'ENTREGADO'),
            'monto': monto, # 👈 Ahora es Decimal
            'tiempo_entrega': tiempo, # 👈 Ahora es Decimal
            'metodo_pago': body.get('metodo_pago', 'EFECTIVO')
        }
        
        table.put_item(Item=item)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Pedido guardado con éxito'})
        }
        
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }