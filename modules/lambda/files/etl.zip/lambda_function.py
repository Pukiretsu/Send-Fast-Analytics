import os
import json
import datetime
import boto3
from boto3.dynamodb.types import TypeDeserializer

# Inicializar el cliente S3 e interpretador de tipos de DynamoDB
s3 = boto3.client('s3')
bucket_id = os.environ.get('S3_BUCKET_ID')
deserializer = TypeDeserializer()

def deserialize_image(dynamodb_image):
    """Convierte el formato nativo DynamoDB JSON a un diccionario estándar de Python"""
    return {k: deserializer.deserialize(v) for k, v in dynamodb_image.items()}

def lambda_handler(event, context):
    for record in event.get('Records', []):
        # Escuchar únicamente los nuevos registros que ingresen a la base de datos
        if record.get('eventName') == 'INSERT':
            raw_image = record['dynamodb'].get('NewImage', {})
            
            if not raw_image:
                continue
                
            # Limpiar los tipos de datos (deserialización)
            clean_data = deserialize_image(raw_image)
            order_id = clean_data.get('orderId')
            
            # Forzar los tipos correctos de datos numéricos para Athena
            clean_data['monto'] = float(clean_data.get('monto', 0))
            clean_data['tiempo_entrega'] = int(clean_data.get('tiempo_entrega', 0))
            
            # Obtener tiempos actuales para el árbol de particiones estructurado
            now = datetime.datetime.utcnow()
            year = now.strftime('%Y')
            month = now.strftime('%m')
            day = now.strftime('%d')
            
            # Formatear la llave exacta según el requisito de la rúbrica 📂
            s3_key = f"orders/year={year}/month={month}/day={day}/{order_id}.json"
            
            # Exportar el archivo JSON limpio directamente al Data Lake en S3
            s3.put_object(
                Bucket=bucket_id,
                Key=s3_key,
                Body=json.dumps(clean_data),
                ContentType='application/json'
            )
            print(f"[ETL PYTHON SUCCESS] Pedido {order_id} exportado de forma particionada hacia S3.")
            
    return {'status': 'Procesado'}